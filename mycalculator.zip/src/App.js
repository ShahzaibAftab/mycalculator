import React from "react";
import Main from './Components/Main'
function App() {
  return (
    <>
    <Main/>
    </>
  );
}

export default App;
