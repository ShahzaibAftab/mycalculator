import React,{useState} from 'react'
import './Main.css'

const Main = () => {

const [Answer,setAnswer]=useState("");

const display=(event)=>
{
     return setAnswer(Answer.concat(event.target.value))
//     console.log(setAnswer(Answer.concat(event.target.value)));
}

const clearScreen = () =>
{
        setAnswer('');
}
const calculate = () =>
{
        return setAnswer(eval(Answer).toString());
}

  return (
    <>
    <div className="bgBody">
        
    <div className="body">
        <div className="screen">
                <input type='text' placeholder='0' value={Answer}/>
        </div> 
        <div className="btnRow1">
                <button className='btn' value='7' onClick={display} >7</button>
                <button className='btn' value='8' onClick={display} >8</button>
                <button className='btn' value='9' onClick={display} >9</button>
                <button className='btn' value='-' onClick={display} >-</button>
        </div>
        <div className="btnRow2">
                <button className='btn'value='6' onClick={display} >6</button>
                <button className='btn'value='5' onClick={display} >5</button>
                <button className='btn'value='4' onClick={display} >4</button>
                <button className='btn'value='*' onClick={display} >*</button>
        </div>
        <div className="btnRow3">
                <button className='btn'value='3' onClick={display} >3</button>
                <button className='btn'value='2' onClick={display} >2</button>
                <button className='btn'value='1' onClick={display} >1</button>
                <button className='btn'value='/' onClick={display} >/</button>
        </div>
        <div className="btnRow4">
                <button className='btn' value='√' onClick={display}>√</button>
                <button className='btn' value='%' onClick={display} >%</button>
                <button className='btn' value='Clear'onClick={clearScreen} >C</button>
                <button className='btn' value='.' onClick={display}>.</button>
         </div>
        <div className="btnRow5">      
                <button className='btn'value='+' onClick={display} >+</button>
                <button className='btn'value='0' onClick={display} >0</button>
                <button className='btnFlat' value='='onClick={calculate}>=</button>
      
        </div>
    </div>
    </div>
    </>
  )
}

export default Main